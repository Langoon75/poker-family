
document.getElementById("enter-btn").addEventListener("click", function () {
  window.location.href = "login.html";
});
